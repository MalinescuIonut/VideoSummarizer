from collections import namedtuple

CacheInformation = namedtuple('CacheInformation', ['size', 'files_count', 'creation_date'])
